function trippleadd(n1) {
    return function(n2) {
      return function(n3) {
        return n1+n2+n3
      }
    }
  }
