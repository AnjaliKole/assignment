function xyz(){
    try{
        document.getElementById("addvalue").innerHTML = trippleadd(10)(20)(30); 
    }
    catch(e){
        if(e instanceof ReferenceError){
            alert("abc.js file not loaded");
        }
    }
}